<?php
class PutoutExcel{
  	public function __construct(){
     	Yii::import("application.extensions.Classes.PHPExcel",1);
 	}

	/*
	*  导出方法，其中参数$data :要导出的数据二维数组，$filename:导出的excel的文件名，$pathname：导出文件存放的路径
	*/
	public  function exportExcel($data,$filename,$pathname='export'){
	   $path=Yii::app()->params['tmp_dir'].$pathname.'/'; //下载文件的存放位置
	   if(!is_dir($path)){
	   mkdir($path);
	   }

	    $filename = $filename?$filename:(time().rand(1, 10).'.xls');
	    $fileurl=$path.$filename;
	    
	    $objPHPExcel = new PHPExcel();
	    
	    foreach ($data as $key => $value) {
	        $rows = $key + 1;
	        foreach ($value as $k => $val) {
	            $str = '';
	            if (floor($k / 26) > 0) {
	                $str .= IntToChr(floor($k / 26)-1);
	            }
	            $cols = $str . chr($k % 26 + 65);
	            //允许针对单元格做扩展处理
	            if (is_array($val)) {
	                
	                if (isset($val['cellFillColor'])) {
	                //填充表格颜色
	                    $objPHPExcel->getActiveSheet()->getStyle($cols . $rows)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
	                    $objPHPExcel->getActiveSheet()->getStyle($cols . $rows)->getFill()->getStartColor()->setARGB($val['cellFillColor']);

	                     //$objPHPExcel->getActiveSheet()->getStyle($cols . $rows)->getFont()->getColor()->setARGB($val['cellFillColor']);//设置单元格字体 PHPExcel_Style_Color::COLOR_RED 
	                }
	                if (isset($val['cellValue'])) {
	                    $val = $val['cellValue'];
	                }
	            }
	            
	            $objPHPExcel->getActiveSheet()->setCellValue($cols.$rows, $val);
	            
	        }
	    }

	    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
	    //$objWriter->save('php://output');     
	    $objWriter->save($fileurl);
	    return array(
	        'fileurl'=>$fileurl,
	        'filename'=>$filename
	    );
	}
}