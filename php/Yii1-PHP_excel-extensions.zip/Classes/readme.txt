1��������ļ�����extensionsĿ¼�»���vendorsĿ¼��



2����������������
	public function actionListexport(){
	    $headerData = array("ID","Tutor","Level","Unit","Lession","Class Time");
	    $bodyData = array();
	    $bodyData[0] = $headerData;
	    $data=array(
	    	'0'=>array('6955','jack','PKԤ����','Lession4','2017-05-28 08:00--08:50'),
	    	'1'=>array('6956','lucy','PKԤ����','Lession5','2017-05-27 08:00--08:50'),
	    	'2'=>array('6957','tom','PKԤ����','Lession6','2017-05-29 08:00--08:50'),
	    );

	    if(!empty($data)){
	        foreach ($data as $key => $value) {
	            $bodyData[]=$value;
	        }
	    }
	    //print_r($bodyData);exit();

	    Yii::import("application.extensions.Classes.*");
	    // require_once('Zend/Search/Lucene.php');
	    $objPHPExcel = new PutoutExcel();
	    $res = $objPHPExcel->exportExcel($bodyData,$filename='�α�����.xls');
	   
		$filename=$res['filename'];
		$fileurl=$res['fileurl'];
		
		ob_end_clean();
		header("Content-Type: application/force-download");
		header("Content-Transfer-Encoding: binary");
		header('Content-Type: application/zip');
		header('Content-Disposition: attachment; filename='.$filename);
		header('Content-Length: '.filesize($fileurl));
		error_reporting(0);
		readfile($fileurl);
		flush();
		ob_flush();
		exit;		
	}