<?php

class HelloWorld extends MyLib
{
	private $greet = '';
    public function __construct()
    {
        $this->greet = 'kiss my airs';
    }

    public function fuck(){
    	return $this->greet.'<br>';
    }
}

