<?php

require __DIR__ . '/../lib/MyLib.php';
require __DIR__ . '/../app/HelloWorld.php';

$demo = new HelloWorld();

$demo->fuck();