<?php

class MyLib
{}

