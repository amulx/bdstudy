这是一个展示phar打包流程的例子，具体介绍请见

http://segmentfault.com/blog/joyqi/1190000002166235
