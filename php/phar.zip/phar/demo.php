<?php
include 'Sample20171019004946.phar';
echo $demo->fuck();